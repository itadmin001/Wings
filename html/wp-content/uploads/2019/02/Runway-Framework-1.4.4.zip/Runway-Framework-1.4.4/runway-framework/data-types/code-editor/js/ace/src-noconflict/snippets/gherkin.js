ace.define('ace/snippets/gherkin', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "gherkin";

});
