<!-- WP Footer Includes -->
<?php wp_footer(); ?>

</body>
</html>
