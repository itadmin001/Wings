ace.define('ace/snippets/ejs', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "ejs";

});
